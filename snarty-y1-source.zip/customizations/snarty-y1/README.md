# SNARTY Y1 customization

This is a development build for the **Innioasis Y1, 480×360**, based on the selected `rebase-upstream` checkout. It is an Android Rockbox application, not a replacement Android OS or a full ROM. Do not flash an APK or theme ZIP as a ROM.

## Included behavior

- Home: Songs, Artists, Playlists, Genre, Year, Search, Settings, System, Now Playing.
- Songs sort by title. Songs and Artists have a `[Most Listened to]` entry which opens artists ranked by the **sum of the play counts of all their tracks**, highest first. Counts come from this device's database; no listening history is invented. Equal totals currently sort in reverse alphabetical order.
- Search first chooses Artist, Song Title, or Album, then First Letter or Type or Speak. First-letter browsing has Numeric, A–Z, and Special Character entries. Composer, a separate First Letter root entry, Shuffle Songs, User Rating, Same as Currently Played, and Tracks By are omitted from the new home/library profile.
- The playing-track context menu starts with album name, artist name, Play Similar Songs, Add to Playlist, and Current Playlist, then retains the existing controls and adds System. Album and artist links open database views; choosing a track uses Rockbox's normal queue replacement behavior.
- Play Similar Songs collects tracks with the current track's exact genre tag, replaces the current queue, and shuffles it. Missing genre/database, party mode, or cancellation leaves the queue unchanged.
- Albums and playlists have `[Shuffle]` above song one. Opening a named playlist or entering an album selects song one, so reaching Shuffle requires scrolling up. Shuffling changes the playback queue, not the saved playlist file. Existing explicit empty-playlist behavior is retained.
- On the physical Y1, two short center-button clicks within 400 ms open the context menu. A single click retains browsing behavior after that short delay; long center press remains available.
- The adapted SNARTY WPS and status/list screen use 480×360 layouts, the original palette/fonts, and native color album art. A missing-art label is displayed only when no art is available. Embed cover art in your audio files or use a supported `cover.jpg`/`cover.bmp` beside the album's tracks.

## Install on a Y1 already running this Rockbox Android fork

1. Back up the existing `.rockbox` folder and playlists to your computer. Save the currently installed APK too, if available. The installed version has not been supplied or checked against a physical player.
2. Install Android Platform Tools on your computer and enable the Y1's existing ADB connection. Confirm the selected device with `adb devices`.
3. Install the supplied APK with `adb install -r rockbox-y1-snarty.apk`. It is signed with this repository's bundled platform key. **If Android reports a signature mismatch or incompatible package, stop and retain the installed app; do not uninstall it to force this update.** Check the installed fork/ROM version before proceeding.
4. Extract `snarty-y1-data.zip`. Merge its `.rockbox` folder into the player's existing `.rockbox` folder at the storage root. The archive contains the matching built Rockbox data plus the theme and database profile. Do not delete the existing folder. If `tagnavi_user.config` already exists, back it up before intentionally replacing that one file.
5. Restart Rockbox. Under Settings → Theme Settings → Browse Themes, select **SNARTY-Y1**. Selecting the theme applies the home-menu order, starts at Home, shows playlist tag titles, and enables Gather Runtime Data. It does not erase your database or music.
6. Initialize/update the database for your music folders if needed. Restart Rockbox if it requests a database commit. Most Listened to reflects only history actually gathered in this database; future plays update it.
7. Verify album playback, the context menu, and volume on the device before using the build regularly. To revert the UI, restore the backed-up theme/config and `tagnavi_user.config`; restore the saved APK using the matching installation method for your existing ROM.

If using ADB to transfer the extracted files, the usual Y1 path is `/sdcard/.rockbox/`. For example, from the extracted data directory: `adb push .rockbox/. /sdcard/.rockbox/`. A computer's file manager may hide `.rockbox`; enable hidden files.

## Voice input prerequisite

The Android text-entry dialog has a Speak button. It invokes an **installed Android speech-recognition activity**, puts the returned words into the same text field, and requires OK to submit. Typing and cancellation remain available. No microphone recording is uploaded by Rockbox itself; the selected speech provider determines network use and privacy behavior.

No recognizer or language model is bundled, and a working recognizer has **not** been verified on the physical Y1. If none is installed/compatible, the app displays that fact and typing remains usable. This is not a claim of working standalone offline speech recognition. The player must have a compatible provider and working microphone for voice search to work.

## Validation and limits

The Y1 ARM/native build, Android Java compilation, APK packaging and v1/v2 signature verification pass. Both 480×360 skins pass the target-specific Rockbox CheckWPS parser. Shared menu/database/queue changes were exercised in the native iPod 6G simulator with a four-track, two-artist fixture. Simulator checks covered home order, alphabetical songs, artist aggregate ranking (18 total plays versus 15 despite the latter artist having the highest individual track count), album selection/Shuffle, context-menu order, genre queue replacement, named-playlist selection/Shuffle, and first-letter song filtering.

Physical Y1 installation, double-click timing, microphone recognition, and actual-device color rendering have not been tested. The provided app is a development build. The repository's Y1 simulator does not compile its Android notification code; the generic SDL target also has a pre-existing duplicate plugin API member, so those are not claimed as passing workflows. The working iPod simulator exercises the shared implementation; the actual Y1 target compiles successfully.

Album browsing follows the repository's existing album-name grouping. Distinct releases with identical album names can therefore be grouped together. Artist ranking scans matching tracks per artist and can take longer on very large libraries; cancellation/progress remains governed by the existing database browser. Existing Rockbox directory-buffer limits still apply.

## Build

The onboarding installation script installs local tool dependencies outside the checkout. Activate `/workspace/setup/env.sh`, then use:

```sh
cd /workspace/builds/y1
make -j5 BUILD_TOOLS_VERSION=28.0.3
make BUILD_TOOLS_VERSION=28.0.3 classes zip unsigned-apk
```

The selected target is `310`, LCD `480×360`, type `n`; NDK r10e/GCC 4.9, SDK platform 19, Build Tools 28.0.3 and JDK 17 are used. Build Tools 28.0.3 is a supported command-line override for the repository's 32-bit 19.1 tools. Source changes are required for the new menu entries; installing only the theme on an older stock build does not implement them.

## Attribution

SNARTY 1.0: Simon Andén / Tirim4, 2025, supplied by the user. Original attribution credits SPAZZ by Chuck Lardo, SNAZZ/SNAZZ2 by Jihoon Kim, SNAZZY by Phil Graves, and elements/code from adwaitapod by even Dook. The SNARTY adaptation is distributed under **CC BY-SA 4.0**, retaining those credits: https://creativecommons.org/licenses/by-sa/4.0/ . Fonts and original assets retain their respective upstream licenses. Rockbox firmware/application changes retain Rockbox's GPL licensing; see `docs/COPYING` and `docs/LICENSES`.
