from pathlib import Path
from zipfile import ZipFile
import subprocess,shutil,json,hashlib,re
base=Path('/workspace/artifacts/snarty-y1/revision-4')
root=base/'simulation'
assert not root.exists(), 'Do not overwrite an existing simulation'
root.mkdir()
fs=root/'rootfs'; shims=root/'bin'; shims.mkdir()
card=fs/'sdcard/.rockbox'; card.mkdir(parents=True)
for directory in ('system/app','system/lib','system/etc/init.d','system/usr/keylayout','data/data/org.rockbox/lib','data/data/update','sdcard/Music','sdcard/Playlists','sdcard/Videos','sdcard/Podcasts'):
 (fs/directory).mkdir(parents=True,exist_ok=True)
for path in ('sdcard/Music/keep.flac','sdcard/Playlists/keep.m3u8','sdcard/.rockbox/config.cfg','sdcard/.rockbox/listening-history-v1.tsv','sdcard/Videos/keep.mp4','sdcard/Podcasts/keep.mp3'):
 (fs/path).write_text('PRESERVE-USER-DATA\n')
(fs/'system/app/org.rockbox.apk').write_text('OLD APP')
(fs/'data/data/org.rockbox/lib/obsolete-test.so').write_text('OLD LIBRARY')
shutil.copy2(base/'SNARTY-Y1-update-from-v0.5.zip',card/'update.zip')
with ZipFile(Path('/workspace/artifacts/snarty-y1/sd-update/upstream-v0.5-update.zip')) as z:
 script=z.read('update/update.sh').decode()
 original_script=script
 old_apk=base/'upstream-v0.5-rockbox.apk';old_apk.write_bytes(z.read('update/rockbox.apk'))
for original in ('/sdcard','/system','/data/data'):
 script=script.replace(original,str(fs/original.lstrip('/')))
(root/'update-under-test.sh').write_text(script)
for name in ('mount','chown','pm','reboot'):
 p=shims/name
 p.write_text('#!/bin/sh\nprintf "%s\\n" "'+name+' $*" >> "'+str(root/'privileged-operations.log')+'"\nexit 0\n')
 p.chmod(0o755)
# Privileged commands are mocked; ordinary extraction/copy/removal runs only in rootfs.
import os
environment=os.environ.copy();environment['PATH']=str(shims)+':'+environment['PATH']
run=subprocess.run(['sh',str(root/'update-under-test.sh')],input='y\n'*2000,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,env=environment,timeout=90)
(root/'simulation.log').write_text(run.stdout)
assert run.returncode==0,run.stdout[-2000:]
assert 'Finished update.' in run.stdout
assert not (card/'update').exists()
assert not (fs/'data/data/org.rockbox/lib/obsolete-test.so').exists()
new_apk=Path('/workspace/artifacts/snarty-y1/revision-4/rockbox-y1-snarty.apk')
assert (fs/'system/app/org.rockbox.apk').read_bytes()==new_apk.read_bytes()
with ZipFile(new_apk) as app:
 for name in app.namelist():
  if name.startswith('lib/armeabi/') and not name.endswith('/'):
   assert (fs/'data/data/org.rockbox/lib'/Path(name).name).read_bytes()==app.read(name),name
 assert (fs/'system/lib/librockbox.so').read_bytes()==app.read('lib/armeabi/librockbox.so')
for path in ('sdcard/Music/keep.flac','sdcard/Playlists/keep.m3u8','sdcard/.rockbox/config.cfg','sdcard/.rockbox/listening-history-v1.tsv','sdcard/Videos/keep.mp4','sdcard/Podcasts/keep.mp3'):
 assert (fs/path).read_text()=='PRESERVE-USER-DATA\n',path
for p in Path('/workspace/rockbox/customizations/snarty-y1/.rockbox').rglob('*'):
 if p.is_file():assert (card/p.relative_to('/workspace/rockbox/customizations/snarty-y1/.rockbox')).read_bytes()==p.read_bytes(),str(p)
assert (fs/'data/data/update/update.sh').read_text()==original_script
log=(root/'privileged-operations.log').read_text()
assert 'reboot' in log
signer='/workspace/setup/android-sdk/build-tools/28.0.3/apksigner'
environment['PATH']='/workspace/setup/sysroot/usr/lib/jvm/java-17-openjdk-amd64/bin:'+environment['PATH']
def certificate(path):
 result=subprocess.run([signer,'verify','--max-sdk-version','19','--print-certs',str(path)],text=True,capture_output=True,env=environment,check=True)
 return re.search(r'Signer #1 certificate SHA-256 digest: (\w+)',result.stdout).group(1)
assert certificate(old_apk)==certificate(new_apk),'Signing certificate differs from official v0.5'
report=json.loads((base/'UPDATE-VALIDATION.json').read_text())
report['host_simulation']='PASS: official v0.5 updater extraction/copy logic; privileged mount/chown/pm/reboot mocked'
report['preserves']='Music, playlists, Videos, Podcasts, existing config.cfg and listening-history-v1.tsv sentinel files preserved in simulation'
report['signing_certificate_matches_official_v0.5']=True
report['official_certificate_check']='Verified JAR/v1 signing for the legacy Android API <=19 target; this target does not use APK v2 signatures.'
report['physical_device_installation']='NOT TESTED'
(base/'UPDATE-VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
