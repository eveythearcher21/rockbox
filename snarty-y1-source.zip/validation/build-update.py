from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,stat,json
root=Path('/workspace/artifacts/snarty-y1/revision-2')
base=Path('/workspace/artifacts/snarty-y1/sd-update/upstream-v0.5-update.zip')
apk=Path('/workspace/artifacts/snarty-y1/revision-2/rockbox-y1-snarty.apk')
theme=Path('/workspace/rockbox/customizations/snarty-y1/.rockbox')
output=root/'SNARTY-Y1-update-from-v0.5.zip'
assert hashlib.sha256(base.read_bytes()).hexdigest()=='2f1b4e7be0094437d29de24b41303e4e52bd1cbb708923649ccbd19f5909b2c3'
with ZipFile(base) as original, ZipFile(apk) as app, ZipFile(output,'w',ZIP_DEFLATED,compresslevel=9) as z:
 for info in original.infolist():
  name=info.filename
  assert not name.startswith('/') and '..' not in Path(name).parts
  assert not stat.S_ISLNK(info.external_attr >> 16)
  if name.endswith('/') or name=='update/rockbox.apk' or name.startswith('update/libs/'):
   continue
  z.writestr(name,original.read(name))
 z.write(apk,'update/rockbox.apk')
 libs=[n for n in app.namelist() if n.startswith('lib/armeabi/') and not n.endswith('/')]
 assert 'lib/armeabi/librockbox.so' in libs and 'lib/armeabi/libmisc.so' in libs
 for name in libs:z.writestr('update/libs/armeabi/'+Path(name).name,app.read(name))
 for p in theme.rglob('*'):
  if p.is_file():z.write(p,p.relative_to(theme).as_posix())
with ZipFile(output) as z, ZipFile(base) as original, ZipFile(apk) as app:
 assert z.testzip() is None
 for info in original.infolist():
  n=info.filename
  if not n.endswith('/') and n!='update/rockbox.apk' and not n.startswith('update/libs/'):
   assert z.read(n)==original.read(n),n
 for n in app.namelist():
  if n.startswith('lib/armeabi/') and not n.endswith('/'):
   assert z.read('update/libs/armeabi/'+Path(n).name)==app.read(n),n
 assert z.read('update/rockbox.apk')==apk.read_bytes()
 assert z.read('tagnavi_user.config')==(theme/'tagnavi_user.config').read_bytes()
 raw_size=sum(i.file_size for i in z.infolist())
digest=hashlib.sha256(output.read_bytes()).hexdigest()
report={'file':output.name,'size':output.stat().st_size,'unpacked_size':raw_size,'sha256':digest,'base_version':'230f848142-260516 / stable-v0.5','upstream_sha256':'2f1b4e7be0094437d29de24b41303e4e52bd1cbb708923649ccbd19f5909b2c3','native_libraries_from_signed_apk':len(libs),'unchanged_components':'All non-Rockbox updater components are byte-identical to official v0.5; theme/profile files are additional.'}
(root/'UPDATE-VALIDATION.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'SHA256SUMS').write_text(digest+'  '+output.name+'\n')
print(json.dumps(report,indent=2))
