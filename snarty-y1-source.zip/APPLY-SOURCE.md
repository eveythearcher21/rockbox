# SNARTY-Y1-4 corresponding source

Base: https://github.com/eveythearcher21/rockbox/tree/9c92b93a5d582b3819a119162a14ad0b4178d2cd

Clone that repository, check out that exact base commit in a clean checkout, then run `git apply --binary /path/to/snarty-y1-source.patch`. The complete patch includes new apps/listening_history.* and listening_stats.*, all other code changes, theme assets, documentation, and tests. See customizations/snarty-y1/README.md for the pinned build toolchain; target 310, normal build, 480x360, VERSION=SNARTY-Y1-4. Use the matching SD updater; do not flash this as a ROM.

The patch was checked against a clean temporary index at the base. The working checkout and index were preserved. Firmware changes retain GPLv2 or later; SNARTY assets retain CC BY-SA 4.0 attribution.
