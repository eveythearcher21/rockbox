Base: https://github.com/eveythearcher21/rockbox/tree/951d8aa303199ae9c544179bb7c5f5e32ff7551f
Apply source.patch with git apply --binary on that exact base. Full source is also on this release branch. See TEST-REPORT.md for build reproduction.
